package com.codegama.todolistapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;

import com.google.firebase.storage.FirebaseStorage;


public class feedback extends AppCompatActivity {
    RatingBar ratingBar;
    Button sendButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);


        ratingBar = findViewById(R.id.ratingBar);
        sendButton = findViewById(R.id.send_button);
        TextView ratingText;
        ratingText = findViewById(R.id.ratingText);


        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendEmail();
            }

            private void sendEmail() {
                int rating = (int) ratingBar.getRating();

                // Create a subject and body for the email
                String subject = "Feedback on my app";
                String body = "My app received a rating of " + rating + " stars!";

                // Create an Intent to compose an email
                Intent emailIntent = new Intent(Intent.ACTION_SENDTO, Uri.fromParts(
                        "mailto", "DailyTaskoto@gmail.com", null));
                emailIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
                emailIntent.putExtra(Intent.EXTRA_TEXT, body);

                // Start the email client activity
                startActivity(Intent.createChooser(emailIntent, "Send feedback via email"));
            }
        });
        
        

        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                updateRatingText(rating);
            }

            private void updateRatingText(float rating) {

                    String grade;
                    if (rating < 2) {
                        grade = "Poor";
                    } else if (rating < 3) {
                        grade = "Fair";
                    } else if (rating < 4) {
                        grade = "Good";
                    } else if (rating < 5) {
                        grade = "Very good";
                    } else {
                        grade = "Excellent";
                    }

                    String text = "Your rating: " + rating + " (" + grade + ")";
                    ratingText.setText(text);
                }

        });



    }
}