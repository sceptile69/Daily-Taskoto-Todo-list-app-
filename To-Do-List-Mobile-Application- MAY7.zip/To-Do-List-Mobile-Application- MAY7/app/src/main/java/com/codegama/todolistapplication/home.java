package com.codegama.todolistapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toolbar;

import com.codegama.todolistapplication.activity.MainActivity;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class home extends AppCompatActivity {


    DrawerLayout drawerLayout;
    NavigationView navigationView;
    Toolbar toolbar;
    ActionBarDrawerToggle actionBarDrawerToggle;
    //END OF SIDEBAR



    //FIREBASE
    FirebaseAuth auth;

    TextView textView;
    FirebaseUser user;

    ImageView imageView;

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            return true;


        }
        return super.onOptionsItemSelected(item);
    }





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);











        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.navigationView);
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout , R.string.menu_open , R.string.close_menu);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();


        Menu menu = navigationView.getMenu();
        MenuItem logoutButton = menu.findItem(R.id.nav_logout);

        logoutButton.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                AlertDialog.Builder builder = new AlertDialog.Builder(home.this);
                builder.setTitle("Logout");
                builder.setMessage("Are you sure you want to log out?");
                builder.setPositiveButton("Logout", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        FirebaseAuth.getInstance().signOut();
                        Intent intent = new Intent(home.this, Login.class);
                        startActivity(intent);
                        finish();


                    }
                });

                builder.setNegativeButton("Cancel", null);
                builder.show();
                return true;
            }
        });



        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                switch (item.getItemId()) {
                    case R.id.nav_category:
                        Intent categoryIntent = new Intent(home.this, category.class);
                        startActivity(categoryIntent);
                        break;

                    case R.id.nav_archive:
                        Intent archiveIntent = new Intent(home.this, archive.class);
                        startActivity(archiveIntent);
                        break;


                    case R.id.nav_help:
                        Intent helpIntent = new Intent(home.this, help.class);
                        startActivity(helpIntent);
                        break;



                    case R.id.nav_settings:
                        Intent settingIntent = new Intent(home.this, settings.class);
                        startActivity(settingIntent);
                        break;

                }

                return true;
            }
        });

        imageView =(ImageView) findViewById(R.id.add_task);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentLoadNewActivity = new Intent(home.this, MainActivity.class);
                startActivity(intentLoadNewActivity);
            }
        });









    }



}